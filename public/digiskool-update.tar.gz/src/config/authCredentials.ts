import { UserRole } from '../types.ts';

export interface QuickAccountCredential {
  role: UserRole;
  label: string;
  email: string;
  description: string;
  badge: string;
  badgeColor: string;
  campusAccess: string;
  department: string;
  iconName: 'Shield' | 'Briefcase' | 'UserCheck' | 'User' | 'GraduationCap';
}

/**
 * Consolidated institutional staff directory for DigiSkool
 */
export const ALL_LOGIN_CREDENTIALS: QuickAccountCredential[] = [
  {
    role: 'main_admin',
    label: 'Main Admin (Adnan Rao)',
    email: 'adnanmrao@gmail.com',
    description: 'Master administrative authority, system settings, financial controls & user security',
    badge: 'Full Master Access',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    campusAccess: 'Both Campuses (DGSL Lahore & DGSO Okara)',
    department: 'Executive Governance',
    iconName: 'Shield'
  },
  {
    role: 'main_admin',
    label: 'James Hunt (Main Admin)',
    email: 'jameshut629@gmail.com',
    description: 'Master administrative authority & institutional owner access',
    badge: 'Full Master Access',
    badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
    campusAccess: 'Both Campuses (DGSL Lahore & DGSO Okara)',
    department: 'Executive Governance',
    iconName: 'Shield'
  },
  {
    role: 'main_admin',
    label: 'DigiSkool Admin (Lahore)',
    email: 'admindigiskoollhr@gmail.com',
    description: 'Campus administrator, enrollment oversight & operations',
    badge: 'Full Master Access',
    badgeColor: 'bg-red-500/20 text-red-300 border-red-500/40',
    campusAccess: 'Both Campuses (DGSL Lahore & DGSO Okara)',
    department: 'Executive Governance',
    iconName: 'Shield'
  },
  {
    role: 'main_admin',
    label: 'Adnan Rao (Main Admin)',
    email: 'adnamrao@gmail.com',
    description: 'Master administrative authority, campus controls & finance',
    badge: 'Full Master Access',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    campusAccess: 'Both Campuses (DGSL Lahore & DGSO Okara)',
    department: 'Executive Governance',
    iconName: 'Shield'
  },
  {
    role: 'main_admin',
    label: 'Narmi (Main Admin)',
    email: 'narmi75@gmail.com',
    description: 'Master administrative authority & institutional management',
    badge: 'Full Master Access',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
    campusAccess: 'Both Campuses (DGSL Lahore & DGSO Okara)',
    department: 'Executive Governance',
    iconName: 'Shield'
  },
  {
    role: 'main_admin',
    label: 'Rao Furqan (Main Admin)',
    email: 'raofurqan2000@gmail.com',
    description: 'Master administrative authority & portal security oversight',
    badge: 'Full Master Access',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    campusAccess: 'Both Campuses (DGSL Lahore & DGSO Okara)',
    department: 'Executive Governance',
    iconName: 'Shield'
  },
  {
    role: 'principal',
    label: 'Principal',
    email: 'principal@digiskool.pk',
    description: 'Academic governance, faculty management, institutional admissions & approvals',
    badge: 'Executive Access',
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    campusAccess: 'All Departments & Campuses',
    department: 'Academic Leadership',
    iconName: 'Briefcase'
  },
  {
    role: 'admin_hr',
    label: 'Admin / HR (Miss Asma)',
    email: 'hr@digiskool.pk',
    description: 'Staff attendance rosters, leave approvals, institutional HR & operations',
    badge: 'Operations Access',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    campusAccess: 'Both Campuses (DGSL & DGSO)',
    department: 'Administration & HR',
    iconName: 'UserCheck'
  },
  {
    role: 'teacher',
    label: 'Lead Faculty / Instructor',
    email: 'teacher@digiskool.pk',
    description: 'Assigned digital courses, student batch rosters & curriculum execution',
    badge: 'Faculty Access',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
    campusAccess: 'Assigned Batches (Lahore & Okara)',
    department: 'Faculty of Digital Skills',
    iconName: 'User'
  }
];

export const MAIN_ADMIN_EMAIL = 'adnanmrao@gmail.com';
